// Масив за съхранение на навиците
var habits = [];
var nextId = 1;

// Функция за рендиране на списъка
function render() {
  var list = document.getElementById('habit-list');
  var emptyMsg = document.getElementById('empty-msg');

  list.innerHTML = '';

  // Ако няма навици, показваме съобщение
  if (habits.length === 0) {
    list.appendChild(emptyMsg);
    emptyMsg.style.display = 'block';
  } else {
    emptyMsg.style.display = 'none';

    // Цикъл за всеки навик
    for (var i = 0; i < habits.length; i++) {
      var h = habits[i];

      var card = document.createElement('div');
      card.className = 'habit-card' + (h.done ? ' done' : '');

      var checkBtn = document.createElement('button');
      checkBtn.className = 'check-btn';
      checkBtn.textContent = h.done ? '✓' : '';
      checkBtn.setAttribute('data-id', h.id);
      checkBtn.onclick = (function(id) {
        return function() { toggle(id); };
      })(h.id);

      var nameSpan = document.createElement('span');
      nameSpan.className = 'habit-name';
      nameSpan.textContent = h.name;

      var delBtn = document.createElement('button');
      delBtn.className = 'del-btn';
      delBtn.textContent = '×';
      delBtn.setAttribute('data-id', h.id);
      delBtn.onclick = (function(id) {
        return function() { deleteHabit(id); };
      })(h.id);

      card.appendChild(checkBtn);
      card.appendChild(nameSpan);
      card.appendChild(delBtn);
      list.appendChild(card);
    }
  }

  updateProgress();
}

// Обновяване на прогрес бара
function updateProgress() {
  var done = 0;
  for (var i = 0; i < habits.length; i++) {
    if (habits[i].done) done++;
  }
  var total = habits.length;
  var pct = total === 0 ? 0 : Math.round((done / total) * 100);

  document.getElementById('prog-bar').style.width = pct + '%';
  document.getElementById('prog-label').textContent =
    done + ' / ' + total + ' изпълнени (' + pct + '%)';
}

// Добавяне на навик
function addHabit() {
  var input = document.getElementById('habit-input');
  var name = input.value.trim();

  if (name === '') return; // Ако полето е празно, не правим нищо

  habits.push({ id: nextId, name: name, done: false });
  nextId++;
  input.value = '';
  render();
}

// Превключване на статус (изпълнен / неизпълнен)
function toggle(id) {
  for (var i = 0; i < habits.length; i++) {
    if (habits[i].id === id) {
      if (habits[i].done === false) {
        habits[i].done = true;
      } else {
        habits[i].done = false;
      }
      break;
    }
  }
  render();
}

// Изтриване на навик
function deleteHabit(id) {
  var newHabits = [];
  for (var i = 0; i < habits.length; i++) {
    if (habits[i].id !== id) {
      newHabits.push(habits[i]);
    }
  }
  habits = newHabits;
  render();
}

// Enter клавиш за добавяне
document.getElementById('habit-input').addEventListener('keydown', function(e) {
  if (e.key === 'Enter') {
    addHabit();
  }
});

// Стартираме с начален рендер
render();
